import subprocess
import sys
from pathlib import Path

from main_dragon_quest import SpellArea

TestCase = tuple[tuple[int, int, int, int], tuple[int, int, int, int]]

test_cases: list[TestCase] = [
    ((1, 2, 3, 4), (1, 3, 4, 2)),
    ((3, 4, 1, 2), (1, 3, 4, 2)),
    ((5, 4, 2, 1), (2, 5, 4, 1)),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(args: tuple[int, int, int, int], expected: tuple[int, int, int, int]) -> bool:
    area = SpellArea(*args)
    actual = (
        area.get_left_x(),
        area.get_right_x(),
        area.get_top_y(),
        area.get_bottom_y(),
    )
    print("---------------------------------")
    print(f"輸入：{args}")
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

