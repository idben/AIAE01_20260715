class SpellArea:
    def __init__(self, x1: int, y1: int, x2: int, y2: int) -> None:
        self.__x1 = x1
        self.__y1 = y1
        self.__x2 = x2
        self.__y2 = y2

    def get_left_x(self) -> int:
        pass

    def get_right_x(self) -> int:
        pass

    def get_top_y(self) -> int:
        pass

    def get_bottom_y(self) -> int:
        pass

    # 以下內容不要修改

    def __repr__(self) -> str:
        return f"SpellArea({self.__x1}, {self.__y1}, {self.__x2}, {self.__y2})"

