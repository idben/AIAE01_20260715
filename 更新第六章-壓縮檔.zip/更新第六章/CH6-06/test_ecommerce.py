import subprocess
import sys
from pathlib import Path

from main_ecommerce import RewardVoucher

TestCase = tuple[RewardVoucher, RewardVoucher, str | None, str | None]

test_cases: list[TestCase] = [
    (RewardVoucher("point"), RewardVoucher("point"), "discount", None),
    (RewardVoucher("discount"), RewardVoucher("discount"), "free_shipping", None),
    (RewardVoucher("point"), RewardVoucher("discount"), None, "獎勵券無法兌換"),
    (RewardVoucher("free_shipping"), RewardVoucher("free_shipping"), None, "獎勵券無法兌換"),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(voucher1: RewardVoucher, voucher2: RewardVoucher, expected: str | None, expected_error: str | None) -> bool:
    print("---------------------------------")
    print(f"輸入：{voucher1.voucher_type} + {voucher2.voucher_type}")
    before1 = voucher1.voucher_type
    before2 = voucher2.voucher_type
    try:
        result = voucher1 + voucher2
        actual = result.voucher_type
        print(f"預期：{expected}")
        print(f"實際：{actual}")
        correct = expected_error is None and actual == expected
        if correct and (result is voucher1 or result is voucher2):
            print("兌換要回傳新的 RewardVoucher，不能回傳原本的兩張獎勵券其中一張")
            correct = False
    except Exception as error:
        actual_error = str(error)
        print(f"預期錯誤：{expected_error}")
        print(f"實際錯誤：{actual_error}")
        correct = actual_error == expected_error
    if correct and (voucher1.voucher_type != before1 or voucher2.voucher_type != before2):
        print(f"兌換不能修改原本的兩張獎勵券（{before1} + {before2} 變成 {voucher1.voucher_type} + {voucher2.voucher_type}）")
        correct = False
    if correct:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()
