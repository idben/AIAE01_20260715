class Sword:
    def __init__(self, sword_type: str) -> None:
        self.sword_type = sword_type

