# CH6-06 練習

## 題目

實作 `+` 運算子的自訂合成規則。

- 《勇者鬥惡龍》版：`Sword` 用 `+` 表示武器升階
- 《寶可夢 GO》版：`CandyBundle` 用 `+` 表示糖果包合併
- 電子商務版：`RewardVoucher` 用 `+` 表示會員獎勵券兌換

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 打開對應的 `main_*.py`。
2. 在 class 裡加入 `__add__(self, other)`。
3. 合法組合回傳新的物件。
4. 不合法組合丟出例外，訊息要與規格一致。

## 題目提示

### 《勇者鬥惡龍》版

- 兩把 `bronze` 劍合成 `iron`
- 兩把 `iron` 劍合成 `steel`
- 其他組合要丟出例外，訊息必須是 `無法合成`
- 合法時要回傳新的 `Sword`，不是修改原本的兩把劍

### 《寶可夢 GO》版

- 先確認兩邊糖果包的 `bundle_type` 是否相同
- 小型糖果包用 `small` 表示，可以往 `medium` 升級
- 中型糖果包用 `medium` 表示，可以往 `large` 升級
- 不同等級、或沒有下一階的組合，要丟出例外，訊息必須是 `無法合併`
- 合法時要回傳新的 `CandyBundle`，不是修改原本的兩個糖果包

### 電子商務版

- 先確認兩張會員獎勵券的 `voucher_type` 是否相同
- 點數券可以兌換成折價券
- 折價券可以兌換成免運券
- 不同等級、或沒有下一階的組合，要丟出例外，訊息必須是 `獎勵券無法兌換`
- 合法時要回傳新的 `RewardVoucher`，不是修改原本的兩張獎勵券

## 這題常見錯誤

- 回傳字串而不是新物件
- 例外訊息拼錯
- 改掉原本兩個物件的資料再回傳其中一個，而不是建立新物件

## 這題在測什麼

- `__add__()` 運算子多載
- 例外條件處理
