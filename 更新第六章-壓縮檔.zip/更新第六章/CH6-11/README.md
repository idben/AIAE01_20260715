# CH6-11 練習

## 題目

完成一個可以比大、也可以比小的撲克牌小遊戲。

這一題只有一個版本，不做三種題材。

## 檔案

- `main.py`
- `test.py`

## 執行方式

```bash
python3 test.py
```

## 學生操作步驟

1. 打開 `main.py`。
2. 完成 `CardGame.__init__()`，保存兩個玩家名稱。
3. 完成 `create_round()`，依照模式建立高牌或低牌回合。
4. 完成 `play_round()`，呼叫 `resolve_round()` 並回傳結果文字。
5. 存檔後執行 `python3 test.py`。

## 題目提示

`Card`、`HighCardRound`、`LowCardRound` 都已經寫好。請不要修改 `# 以上內容不要修改` 上方的程式。

### `create_round()`

- `mode` 是 `"high"` 時，回傳 `HighCardRound(card1, card2)`
- `mode` 是 `"low"` 時，回傳 `LowCardRound(card1, card2)`
- 其他模式要丟出 `Exception("未知的比牌模式")`

### `play_round()`

先呼叫傳入物件的 `resolve_round()`。

回傳格式固定：

```text
PLAYER1獲勝：CARD1
PLAYER2獲勝：CARD2
平手：CARD1 和 CARD2
```

其中 `CARD1` 和 `CARD2` 會使用 `Card.__str__()` 的結果，例如 `Ace of Spades`。

## 這題常見錯誤

- 在 `play_round()` 裡重新判斷 high 或 low，沒有使用 `resolve_round()`
- 例外訊息不是精確的 `未知的比牌模式`
- 結果字串多空格或少標點

## 這題在測什麼

- 用共同介面 `resolve_round()` 執行不同回合規則
- 把多型用在實際遊戲流程
- 固定回傳格式是否正確
