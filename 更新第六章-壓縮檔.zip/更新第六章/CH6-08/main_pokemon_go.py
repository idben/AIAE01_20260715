class PokemonSpawn:
    def __init__(self, name: str, location: str) -> None:
        self.name = name
        self.location = location

    def __str__(self) -> str:
        pass

