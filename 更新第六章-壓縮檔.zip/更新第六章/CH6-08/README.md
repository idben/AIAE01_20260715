# CH6-08 練習

## 題目

實作物件的字串顯示格式。

- 《勇者鬥惡龍》版：`Dragon` 顯示龍的自我介紹
- 《寶可夢 GO》版：`PokemonSpawn` 顯示寶可夢出現提示
- 電子商務版：除錯 `ProductListing` 的商品上架資訊

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 打開對應的 `main_*.py`。
2. 完成 `__str__()`。
3. 存檔後執行對應測試。

## 題目提示

`__str__()` 要回傳字串，不要直接呼叫 `print()`。

### 《勇者鬥惡龍》版

這版可以直接照固定格式回傳，因為測試會逐字比對。

格式必須是：

```text
我是COLOR龍NAME
```

例如 `Dragon("史矛革", "紅")` 要回傳：

```text
我是紅龍史矛革
```

### 《寶可夢 GO》版

先放寶可夢名稱，再接出現位置提示。文字順序固定，不能多空格。

格式必須是：

```text
NAME出現在LOCATION附近
```

例如 `PokemonSpawn("皮卡丘", "公園")` 要回傳：

```text
皮卡丘出現在公園附近
```

### 電子商務版

這一版是除錯題。`main_ecommerce.py` 裡已經有 `__str__()`，但目前回傳的格式是錯的。

先看測試預期，再修正 `__str__()` 回傳的字串。文字順序固定，不能多空格。

格式必須是：

```text
NAME上架於CATEGORY分類
```

例如 `ProductListing("無線耳機", "3C")` 要回傳：

```text
無線耳機上架於3C分類
```

## 這題常見錯誤

- 忘記 `return`
- 格式多空格或少逗號
- 在 `__str__()` 裡直接 `print()`，但沒有回傳字串

## 這題在測什麼

- 覆寫內建方法 `__str__()`
- 固定字串格式是否完全一致
