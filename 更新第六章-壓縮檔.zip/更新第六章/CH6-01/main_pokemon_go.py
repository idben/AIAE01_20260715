class MapZone:
    def __init__(self, center_x: int, center_y: int, radius: int) -> None:
        pass

    def get_bounds(self) -> tuple[int, int, int, int]:
        pass
