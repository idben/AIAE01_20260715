class PriceStockRange:
    def __init__(
        self, min_price: int, min_stock: int, price_span: int, stock_span: int
    ) -> None:
        pass

    def get_bounds(self) -> tuple[int, int, int, int]:
        pass
