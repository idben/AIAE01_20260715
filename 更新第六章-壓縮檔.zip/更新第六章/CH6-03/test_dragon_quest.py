import subprocess
import sys
from pathlib import Path

from main_dragon_quest import SpellArea

TestCase = tuple[SpellArea, SpellArea, bool]

test_cases: list[TestCase] = [
    (SpellArea(0, 0, 4, 4), SpellArea(3, 3, 6, 6), True),
    (SpellArea(0, 0, 4, 4), SpellArea(5, 5, 8, 8), False),
    (SpellArea(1, 1, 4, 4), SpellArea(2, 2, 3, 3), True),
    (SpellArea(0, 0, 4, 4), SpellArea(4, 1, 8, 3), True),
    # 對方在左邊：第一個條件要拿自己的 left 比對方的 right
    (SpellArea(3, 0, 6, 4), SpellArea(0, 0, 4, 4), True),
    # y 軸邊碰邊（self 的 top 4 貼著 other 的 bottom 4）：要用 <= 或 >=
    (SpellArea(0, 0, 4, 4), SpellArea(1, 4, 3, 8), True),
    # x 重疊、y 分離：不檢查 y 軸會誤判成重疊
    (SpellArea(0, 0, 4, 4), SpellArea(1, 6, 3, 8), False),
    # y 重疊、x 分離：不檢查 x 軸會誤判成重疊
    (SpellArea(0, 0, 4, 4), SpellArea(6, 1, 8, 3), False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(area1: SpellArea, area2: SpellArea, expected: bool) -> bool:
    print("---------------------------------")
    print(f"輸入：{area1} 與 {area2}")
    actual = area1.overlaps(area2)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

