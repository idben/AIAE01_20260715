# CH6-03 練習

## 題目

完成不同範圍物件的矩形重疊判斷。

- 《勇者鬥惡龍》版：`SpellArea` 用兩個角落表示咒文範圍
- 《寶可夢 GO》版：`MapZone` 用中心點和半徑表示地圖範圍
- 電子商務版：`PromotionRange` 用價格區間和庫存區間表示促銷條件範圍

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 使用已提供的四個 getter method。
2. 比較 `self` 和另一個矩形的四條邊。
3. 四個方向都沒有分離時，回傳 `True`。

## 題目提示

邊界剛好碰到也算重疊。三個版本的 constructor 資料不同，但都已經提供：

- `get_left_x()`
- `get_right_x()`
- `get_top_y()`
- `get_bottom_y()`

`overlaps()` 只需要使用這四個方法，不需要直接碰 private instance variables。

### 《勇者鬥惡龍》版

`SpellArea` 是咒文範圍。這版可以直接用四個比較：自己的左邊要在對方右邊的左側或同一條線上，自己的右邊要在對方左邊的右側或同一條線上，自己的上邊要在對方下邊的上方或同一條線上，自己的下邊要在對方上邊的下方或同一條線上。四個條件都成立，代表咒文範圍沒有和目標分開。

### 《寶可夢 GO》版

`MapZone` 是地圖搜尋範圍。它用中心點和半徑建立，但重疊判斷時仍然透過四個 getter 取得矩形邊界。請先想「兩個區域什麼時候完全分開」：如果左右已經分開，或上下已經分開，就不重疊；反過來，沒有分開就算重疊。

### 電子商務版

`PromotionRange` 是促銷條件範圍。價格可以想成 x 軸，庫存量可以想成 y 軸。它用最低價格、最低庫存、價格跨度和庫存跨度建立，但 `overlaps()` 裡應該使用四個 getter 取得邊界。判斷時可以先檢查價格方向是否分開，再檢查庫存方向是否分開；只要兩個方向都沒有分開，就代表兩個促銷條件可能套到同一批商品。

## 這題常見錯誤

- 第一個條件拿自己的 left 去比對方的 left，而不是對方的 right
- 使用 `<` 或 `>` 導致邊碰邊被判定為不重疊

## 這題在測什麼

- 矩形邊界比較
- 布林條件組合
- 用共同 getter 介面處理不同資料來源
