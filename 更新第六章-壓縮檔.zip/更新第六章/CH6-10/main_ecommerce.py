class ProductDeal:
    def __init__(self, name: str, original_price: int, sale_price: int) -> None:
        self.name = name
        self.original_price = original_price
        self.sale_price = sale_price
        self.discount_value = original_price - sale_price

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ProductDeal):
            return False
        return (
            self.discount_value == other.discount_value
            and self.sale_price == other.sale_price
        )

    def __lt__(self, other: "ProductDeal") -> bool:
        if self.discount_value == other.discount_value:
            return self.sale_price > other.sale_price
        return self.discount_value < other.discount_value

    def __gt__(self, other: "ProductDeal") -> bool:
        if self.discount_value == other.discount_value:
            return self.sale_price < other.sale_price
        return self.discount_value > other.discount_value

    def __str__(self) -> str:
        return f"{self.name} 原價 {self.original_price} 特價 {self.sale_price}"


class DealRound:
    def resolve_round(self) -> int:
        raise NotImplementedError("子類別必須實作 resolve_round()")


# 以上內容不要修改


class BestDealRound(DealRound):
    def __init__(self, deal1: ProductDeal, deal2: ProductDeal) -> None:
        self.deal1 = deal1
        self.deal2 = deal2

    def resolve_round(self) -> int:
        if self.deal1 < self.deal2:
            return 1
        if self.deal2 < self.deal1:
            return 2
        return 0


class BudgetDealRound(DealRound):
    def __init__(self, deal1: ProductDeal, deal2: ProductDeal) -> None:
        self.deal1 = deal1
        self.deal2 = deal2

    def resolve_round(self) -> int:
        if self.deal1 > self.deal2:
            return 1
        if self.deal2 > self.deal1:
            return 2
        return 0
