class RaidPokemon:
    def __init__(self, name: str, cp: int, attack_iv: int) -> None:
        self.name = name
        self.cp = cp
        self.attack_iv = attack_iv
        self.battle_power = cp + attack_iv * 100

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RaidPokemon):
            return False
        return self.battle_power == other.battle_power

    def __lt__(self, other: "RaidPokemon") -> bool:
        return self.battle_power < other.battle_power

    def __gt__(self, other: "RaidPokemon") -> bool:
        return self.battle_power > other.battle_power

    def __str__(self) -> str:
        return f"{self.name} CP {self.cp} 攻擊 IV {self.attack_iv}"


class Round:
    def resolve_round(self) -> int:
        raise NotImplementedError("子類別必須實作 resolve_round()")


# 以上內容不要修改


class HighRaidPowerRound(Round):
    pass


class LowRaidPowerRound(Round):
    pass
