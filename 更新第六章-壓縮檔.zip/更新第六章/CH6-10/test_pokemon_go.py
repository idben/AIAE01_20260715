import subprocess
import sys
from pathlib import Path

from main_pokemon_go import HighRaidPowerRound, LowRaidPowerRound, RaidPokemon

TestCase = tuple[RaidPokemon, RaidPokemon, int, int]

test_cases: list[TestCase] = [
    (RaidPokemon("皮卡丘", 1200, 15), RaidPokemon("噴火龍", 2400, 2), 1, 2),
    (RaidPokemon("妙蛙花", 2100, 8), RaidPokemon("水箭龜", 2200, 6), 1, 2),
    (RaidPokemon("伊布", 800, 10), RaidPokemon("伊布", 800, 10), 0, 0),
    (RaidPokemon("卡比獸", 2500, 1), RaidPokemon("怪力", 1800, 12), 2, 1),
]


def label(pokemon1: RaidPokemon, pokemon2: RaidPokemon, result: int) -> RaidPokemon | str:
    if result == 1:
        return pokemon1
    if result == 2:
        return pokemon2
    return "平手"


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    pokemon1: RaidPokemon, pokemon2: RaidPokemon, expected_high: int, expected_low: int
) -> bool:
    print("---------------------------------")
    print(f"輸入：{pokemon1} vs {pokemon2}")
    high_result = HighRaidPowerRound(pokemon1, pokemon2).resolve_round()
    low_result = LowRaidPowerRound(pokemon1, pokemon2).resolve_round()
    print(f"預期高戰力勝者：{label(pokemon1, pokemon2, expected_high)}")
    print(f"實際高戰力勝者：{label(pokemon1, pokemon2, high_result)}")
    print(f"預期低戰力勝者：{label(pokemon1, pokemon2, expected_low)}")
    print(f"實際低戰力勝者：{label(pokemon1, pokemon2, low_result)}")
    if high_result == expected_high and low_result == expected_low:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()
