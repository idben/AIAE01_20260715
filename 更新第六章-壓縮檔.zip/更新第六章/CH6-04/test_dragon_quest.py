import subprocess
import sys
from pathlib import Path

from main_dragon_quest import LargeMonster

TestCase = tuple[LargeMonster, int, int, int, int, bool]

test_cases: list[TestCase] = [
    (LargeMonster("巨龍", -1, -2, 1, 2, 1), -2, -3, 0, 0, True),
    (LargeMonster("巨像", 2, 2, 2, 2, 2), 0, 1, 1, 0, True),
    (LargeMonster("黃金龍", 0, 0, 5, 5, 10), 4, 0, 5, 1, False),
    (LargeMonster("高塔魔物", 0, 0, 10, 2, 1), 0, 4, 1, 5, True),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(monster: LargeMonster, x1: int, y1: int, x2: int, y2: int, expected: bool) -> bool:
    print("---------------------------------")
    print(f"輸入：{monster.name} at ({monster.pos_x}, {monster.pos_y})")
    print(f"範圍：({x1}, {y1}) 到 ({x2}, {y2})")
    actual = monster.in_area(x1, y1, x2, y2)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

