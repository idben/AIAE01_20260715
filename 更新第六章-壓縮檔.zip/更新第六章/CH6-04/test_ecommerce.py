import subprocess
import sys
from pathlib import Path

from main_ecommerce import ProductSegment

TestCase = tuple[ProductSegment, int, int, int, int, bool]

test_cases: list[TestCase] = [
    (ProductSegment("高庫存熱銷", 500, 80, 40, 120, 1), 540, 60, 700, 110, True),
    (ProductSegment("低價清倉", 120, 15, 20, 80, 2), 200, 40, 300, 80, False),
    (ProductSegment("補貨觀察", 300, 30, 30, 100, 3), 240, 10, 310, 45, True),
    (ProductSegment("高單價少量", 900, 5, 10, 200, 1), 100, 20, 400, 80, False),
    # 中心不是角落：碰撞框價格 [440, 560]、庫存 [60, 100]，把中心當角落往右上展開會誤判成不重疊
    (ProductSegment("中心非角落", 500, 80, 40, 120, 1), 440, 60, 480, 70, True),
    # 各推半個跨度：碰撞框價格 [440, 560]，推整個跨度會變成 [380, 620] 而誤判成重疊
    (ProductSegment("跨度推一半", 500, 80, 40, 120, 1), 380, 60, 430, 70, False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(
    segment: ProductSegment, x1: int, y1: int, x2: int, y2: int, expected: bool
) -> bool:
    print("---------------------------------")
    print(f"輸入：{segment.name} at price={segment.price}, stock={segment.stock}")
    print(f"促銷範圍：價格 {x1} 到 {x2}，庫存 {y1} 到 {y2}")
    actual = segment.in_area(x1, y1, x2, y2)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()
