# CH6-04 練習

## 題目

完成大型物件的碰撞框，並覆寫 `in_area()`。

- 《勇者鬥惡龍》版：`LargeMonster` 用碰撞框判斷咒文是否命中
- 《寶可夢 GO》版：`EventObject` 用碰撞框判斷玩家是否進入互動範圍
- 電子商務版：`ProductSegment` 用碰撞框判斷商品分群是否碰到促銷條件

這題已經提供 `Rectangle` 類別。請用 `Rectangle` 建立 private `__hit_box`，並在 `in_area()` 裡建立另一個 `Rectangle` 代表傳入的檢查範圍，再呼叫 `overlaps()` 判斷是否重疊。不要寫成「整個物件必須完全在範圍內」。

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`
- `main_ecommerce.py`
- `test_ecommerce.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
python3 test_ecommerce.py
```

## 學生操作步驟

1. 在子類別 constructor 中呼叫父類別 constructor。
2. 保存子類別自己的尺寸與範圍資料。
3. 用中心值與尺寸建立 private `__hit_box`，型別是 `Rectangle`。
4. 在 `in_area()` 中建立檢查範圍 `Rectangle`，並用 `overlaps()` 回傳是否重疊。

## 題目提示

碰撞框不是從角落開始算，而是從中心值往兩側推開。遊戲版本會用中心 x、中心 y 搭配寬高；電子商務版會用中心價格、中心庫存搭配價格跨度與庫存跨度。

### 《勇者鬥惡龍》版

`LargeMonster` 是大型怪物。這版可以直接照規則建立碰撞框：中心 x 左右各推半個寬度，中心 y 上下各推半個高度。原因是 `pos_x` 和 `pos_y` 是怪物中心，不是角落。請把碰撞框存成 private `__hit_box`，而且它應該是一個 `Rectangle`。`in_area()` 要把咒文範圍也建立成 `Rectangle`，再用 `Rectangle.overlaps()` 判斷怪物碰撞框是否和咒文範圍重疊；不要要求整隻怪物完全被包住。

### 《寶可夢 GO》版

`EventObject` 是地圖活動物件。建立 `__hit_box` 時，先從中心點出發，再用寬度決定左右距離，用高度決定上下距離。`interaction_range` 是額外互動距離，所以四個方向都要再往外多推一段。`in_area()` 不要只看中心點，也不要要求整個活動物件完全被包住。

### 電子商務版

`ProductSegment` 是商品分群。價格可以想成 x 軸，庫存可以想成 y 軸。中心價格和中心庫存不是範圍角落，建立碰撞框時，中心價格左右各推半個價格跨度，中心庫存上下各推半個庫存跨度，規則跟遊戲版的寬高完全一樣。

這裡要特別注意，前面 CH6-01 到 CH6-03 的電子商務版是「最低價格加上跨度」的角落算法，這一版不是。這一版的 `price` 與 `stock` 是分群的中心，不是最低值，所以要往兩側各推一半。

`in_area()` 要判斷商品分群是否碰到指定促銷條件範圍。

## 這題常見錯誤

- 忘記呼叫 `super().__init__()`
- 還是只用中心點判斷
- 寫成整個碰撞框必須完全被範圍包住
- 忘記使用已提供的 `Rectangle.overlaps()`
- 尺寸加減方向寫反

## 這題在測什麼

- 子類別覆寫方法
- 使用碰撞框取代中心點判斷
- 多型介面 `in_area()`
