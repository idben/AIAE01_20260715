class RaidPokemon:
    def __init__(self, name: str, cp: int, attack_iv: int) -> None:
        pass

    def __eq__(self, other: object) -> bool:
        pass

    def __lt__(self, other: "RaidPokemon") -> bool:
        pass

    def __gt__(self, other: "RaidPokemon") -> bool:
        pass

    # 以下內容不要修改

    def __str__(self) -> str:
        return f"{self.name} CP {self.cp} 攻擊 IV {self.attack_iv}"
