import subprocess
import sys
from pathlib import Path

from main_pokemon_go import RaidPokemon

TestCase = tuple[str, int, int, str, int, int, bool, bool]

test_cases: list[TestCase] = [
    ("皮卡丘", 1200, 15, "噴火龍", 2400, 2, False, True),
    ("妙蛙花", 2100, 8, "水箭龜", 2200, 6, False, True),
    ("伊布", 800, 10, "伊布", 800, 10, True, False),
    ("卡比獸", 2500, 1, "怪力", 1800, 12, False, False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(
    name1: str,
    cp1: int,
    attack_iv1: int,
    name2: str,
    cp2: int,
    attack_iv2: int,
    expected_eq: bool,
    expected_gt: bool,
) -> bool:
    pokemon1 = RaidPokemon(name1, cp1, attack_iv1)
    pokemon2 = RaidPokemon(name2, cp2, attack_iv2)
    actual_eq = pokemon1 == pokemon2
    actual_gt = pokemon1 > pokemon2
    actual_lt = pokemon1 < pokemon2
    expected_lt = not (expected_eq or expected_gt)
    print("---------------------------------")
    print(f"輸入：{pokemon1} vs {pokemon2}")
    print(f"預期：eq={expected_eq}, gt={expected_gt}, lt={expected_lt}")
    print(f"實際：eq={actual_eq}, gt={actual_gt}, lt={actual_lt}")
    if (actual_eq, actual_gt, actual_lt) == (expected_eq, expected_gt, expected_lt):
        print("通過")
        return True
    print("失敗")
    return False


def test_not_a_pokemon() -> bool:
    pokemon = RaidPokemon("皮卡丘", 1200, 15)
    print("---------------------------------")
    print(f"輸入：{pokemon} vs 字串 '皮卡丘'")
    print("預期：eq=False（跟不是 RaidPokemon 的物件比較要回傳 False，不能出錯）")
    try:
        actual_eq = pokemon == "皮卡丘"
    except AttributeError:
        print("實際：AttributeError（__eq__ 沒有先確認對方是不是 RaidPokemon）")
        print("失敗")
        return False
    print(f"實際：eq={actual_eq}")
    if actual_eq is False:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if test_not_a_pokemon():
        passed += 1
    else:
        failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()
