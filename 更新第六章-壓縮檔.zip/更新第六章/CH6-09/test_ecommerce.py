import subprocess
import sys
from pathlib import Path

from main_ecommerce import ProductDeal

TestCase = tuple[str, int, int, str, int, int, bool, bool]

test_cases: list[TestCase] = [
    ("耳機", 3000, 2100, "鍵盤", 2800, 2300, False, True),
    ("水壺", 1200, 900, "背包", 1500, 1200, False, True),
    ("滑鼠", 1000, 700, "滑鼠", 1000, 700, True, False),
    ("外套", 3600, 3200, "鞋子", 2500, 1800, False, False),
    ("檯燈", 2000, 1000, "音響", 1500, 1000, False, True),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(
    name1: str,
    original_price1: int,
    sale_price1: int,
    name2: str,
    original_price2: int,
    sale_price2: int,
    expected_eq: bool,
    expected_gt: bool,
) -> bool:
    deal1 = ProductDeal(name1, original_price1, sale_price1)
    deal2 = ProductDeal(name2, original_price2, sale_price2)
    actual_eq = deal1 == deal2
    actual_gt = deal1 > deal2
    actual_lt = deal1 < deal2
    expected_lt = not (expected_eq or expected_gt)
    print("---------------------------------")
    print(f"輸入：{deal1} vs {deal2}")
    print(f"預期：eq={expected_eq}, gt={expected_gt}, lt={expected_lt}")
    print(f"實際：eq={actual_eq}, gt={actual_gt}, lt={actual_lt}")
    if (actual_eq, actual_gt, actual_lt) == (expected_eq, expected_gt, expected_lt):
        print("通過")
        return True
    print("失敗")
    return False


def test_not_a_deal() -> bool:
    deal = ProductDeal("耳機", 3000, 2100)
    print("---------------------------------")
    print(f"輸入：{deal} vs 字串 '耳機'")
    print("預期：eq=False（跟不是 ProductDeal 的物件比較要回傳 False，不能出錯）")
    try:
        actual_eq = deal == "耳機"
    except AttributeError:
        print("實際：AttributeError（__eq__ 沒有先確認對方是不是 ProductDeal）")
        print("失敗")
        return False
    print(f"實際：eq={actual_eq}")
    if actual_eq is False:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if test_not_a_deal():
        passed += 1
    else:
        failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()
