import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Card

TestCase = tuple[str, str, str, str, bool, bool]

test_cases: list[TestCase] = [
    ("Ace", "Hearts", "Queen", "Hearts", False, True),
    ("2", "Spades", "2", "Hearts", False, True),
    ("Ace", "Spades", "Ace", "Spades", True, False),
    ("King", "Clubs", "King", "Hearts", False, False),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass

def test(rank1: str, suit1: str, rank2: str, suit2: str, expected_eq: bool, expected_gt: bool) -> bool:
    card1 = Card(rank1, suit1)
    card2 = Card(rank2, suit2)
    actual_eq = card1 == card2
    actual_gt = card1 > card2
    actual_lt = card1 < card2
    expected_lt = not (expected_eq or expected_gt)
    print("---------------------------------")
    print(f"輸入：{card1} vs {card2}")
    print(f"預期：eq={expected_eq}, gt={expected_gt}, lt={expected_lt}")
    print(f"實際：eq={actual_eq}, gt={actual_gt}, lt={actual_lt}")
    if (actual_eq, actual_gt, actual_lt) == (expected_eq, expected_gt, expected_lt):
        print("通過")
        return True
    print("失敗")
    return False


def test_not_a_card() -> bool:
    card = Card("Ace", "Spades")
    print("---------------------------------")
    print(f"輸入：{card} vs 字串 'Ace'")
    print("預期：eq=False（跟不是 Card 的物件比較要回傳 False，不能出錯）")
    try:
        actual_eq = card == "Ace"
    except AttributeError:
        print("實際：AttributeError（__eq__ 沒有先確認對方是不是 Card）")
        print("失敗")
        return False
    print(f"實際：eq={actual_eq}")
    if actual_eq is False:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if test_not_a_card():
        passed += 1
    else:
        failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 測試失敗 ==============")
    print(f"{passed} 通過，{failed} 失敗")


main()

