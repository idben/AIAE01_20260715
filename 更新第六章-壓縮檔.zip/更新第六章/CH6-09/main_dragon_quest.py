SUITS: list[str] = ["Clubs", "Diamonds", "Hearts", "Spades"]

RANKS: list[str] = [
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "Jack",
    "Queen",
    "King",
    "Ace",
]


class Card:
    def __init__(self, rank: str, suit: str) -> None:
        pass

    def __eq__(self, other: object) -> bool:
        pass

    def __lt__(self, other: "Card") -> bool:
        pass

    def __gt__(self, other: "Card") -> bool:
        pass

    # 以下內容不要修改

    def __str__(self) -> str:
        return f"{self.rank} of {self.suit}"

