import random

SpawnCard = tuple[str, str]


class FieldEventDeck:
    BIOMES: list[str] = ["公園", "城市", "河岸", "山區"]
    TIERS: list[str] = ["常見", "不常見", "稀有", "非常稀有", "巢穴", "誘餌", "暗影", "蛋", "田野調查", "火箭隊", "團體戰", "傳說", "幻之"]

    def __init__(self) -> None:
        self.__cards: list[SpawnCard] = []
        self.create_deck()

    def create_deck(self) -> None:
        self.__cards = []
        for biome in self.BIOMES:
            for tier in self.TIERS:
                self.__cards.append((tier, biome))

    def shuffle_deck(self) -> None:
        random.shuffle(self.__cards)

    def deal_card(self) -> SpawnCard | None:
        if len(self.__cards) == 0:
            return None
        return self.__cards.pop()

    def __str__(self) -> str:
        return f"事件牌組剩下 {len(self.__cards)} 張卡"
