# CH4-05 練習

## 題目

這一課用兩種遊戲情境練習「建立牌組、洗牌、發牌」的抽象化 (Abstraction)。

- 《勇者鬥惡龍》版：完成 `AdventureDeck`
- 《寶可夢 GO》版：完成 `FieldEventDeck`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 《勇者鬥惡龍》操作步驟

1. 先看 `AdventureDeck` 的類別變數：`REGIONS` 是中文區域清單，`RANKS` 在這一課記的是中文遭遇內容清單
2. 再看實例變數 `__cards`：它記的是這副冒險事件牌組目前還剩哪些卡，會隨著發牌變少
3. 先完成建構子：新牌組一開始要準備一個空的私有列表，建構子結束時應該已經建立好完整牌組
4. 再完成 `create_deck()`：把 `REGIONS` 和 `RANKS` 的所有中文組合放進 `__cards`
5. 接著完成 `shuffle_deck()`：洗亂同一個 `__cards` 列表，不要把洗牌函式的回傳值存成新牌組
6. 最後完成 `deal_card()`：有牌時從牌組尾端發出一張，讓牌組真的少一張；沒有牌時回傳 `None`
7. 執行 `python3 test_dragon_quest.py` 確認順序與洗牌結果

## 《寶可夢 GO》操作步驟

1. 先看 `FieldEventDeck` 的類別變數：`BIOMES` 是中文地區類型清單，`TIERS` 是中文事件等級清單
2. 再看實例變數 `__cards`：它記的是這副地圖事件牌組目前還剩哪些卡，會隨著發牌變少
3. 先完成建構子：新牌組一開始要準備一個空的私有列表，建構子結束時應該已經建立好完整牌組
4. 再完成 `create_deck()`：把 `BIOMES` 和 `TIERS` 的所有中文組合放進 `__cards`
5. 接著完成 `shuffle_deck()`：洗亂同一個 `__cards` 列表，不要把洗牌函式的回傳值存成新牌組
6. 最後完成 `deal_card()`：有牌時從牌組尾端發出一張，讓牌組真的少一張；沒有牌時回傳 `None`
7. 執行 `python3 test_pokemon_go.py` 確認順序與洗牌結果

## 題目提示

- 《勇者鬥惡龍》版的一張 `EncounterCard` 是「遭遇內容」和「區域」組成的 tuple
- 《寶可夢 GO》版的一張 `SpawnCard` 是「事件等級」和「地區類型」組成的 tuple
- tuple 順序要照測試需求放，不能自己交換位置
- `deal_card()` 回傳的卡片可以拿去顯示、結算事件，或記錄玩家抽到了什麼
- `create_deck()` 和 `shuffle_deck()` 都是在改自己這副牌的 `__cards`

## 常見錯誤

- tuple 順序寫反
- 忘了在建構子呼叫 `create_deck()`
- `shuffle_deck()` 把洗牌函式的回傳值存回去
- 沒牌時沒有回傳 `None`
- `deal_card()` 取牌後，列表沒有真的少一張

## 這題在測什麼

- 類別變數的使用
- 受控集合的初始化
- 就地洗牌
- 從尾端取牌的狀態管理
