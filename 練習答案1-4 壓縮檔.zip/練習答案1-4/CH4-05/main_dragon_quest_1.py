import random

EncounterCard = tuple[str, str]


class AdventureDeck:
    REGIONS: list[str] = ["城鎮", "草原", "洞窟", "城堡"]
    RANKS: list[str] = ["史萊姆", "德拉奇", "幽靈", "魔法師", "蠍子", "狼", "魔像", "飛龍", "騎士", "龍", "頭目", "大惡魔", "龍王"]

    def __init__(self) -> None:
        self.__cards: list[EncounterCard] = []
        self.create_deck()

    def create_deck(self) -> None:
        cards: list[EncounterCard] = []
        for region in self.REGIONS:
            for rank in self.RANKS:
                cards.append((rank, region))
        self.__cards = cards

    def shuffle_deck(self) -> None:
        random.shuffle(self.__cards)

    def deal_card(self) -> EncounterCard | None:
        if not self.__cards:
            return None
        return self.__cards.pop()

    def __str__(self) -> str:
        return f"牌組剩下 {len(self.__cards)} 張事件卡"
