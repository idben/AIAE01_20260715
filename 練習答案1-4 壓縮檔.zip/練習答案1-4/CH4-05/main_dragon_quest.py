import random

EncounterCard = tuple[str, str]


class AdventureDeck:
    REGIONS: list[str] = ["城鎮", "草原", "洞窟", "城堡"]
    RANKS: list[str] = ["史萊姆", "德拉奇", "幽靈", "魔法師", "蠍子", "狼", "魔像", "飛龍", "騎士", "龍", "頭目", "大惡魔", "龍王"]

    def __init__(self) -> None:
        self.__cards: list[EncounterCard] = []
        self.create_deck()

    def create_deck(self) -> None:
        self.__cards = []
        for region in self.REGIONS:
            for rank in self.RANKS:
                self.__cards.append((rank, region))

    def shuffle_deck(self) -> None:
        random.shuffle(self.__cards)

    def deal_card(self) -> EncounterCard | None:
        if len(self.__cards) == 0:
            return None
        return self.__cards.pop()

    def __str__(self) -> str:
        return f"牌組剩下 {len(self.__cards)} 張事件卡"
