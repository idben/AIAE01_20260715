import subprocess
import sys
from pathlib import Path
import random

from main_pokemon_go import FieldEventDeck

Card = tuple[str, str]
TestCase = tuple[str, int, list[Card | None]]

run_cases: list[TestCase] = [
    (
        "deal_card",
        4,
        [
            ("幻之", "山區"),
            ("傳說", "山區"),
            ("團體戰", "山區"),
            ("火箭隊", "山區"),
        ],
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        "shuffle_deck",
        3,
        [
            ("田野調查", "公園"),
            ("團體戰", "河岸"),
            ("火箭隊", "山區"),
        ],
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(action: str, num_cards: int, expected: list[Card | None]) -> bool:
    print("---------------------------------")
    deck = FieldEventDeck()
    random.seed(1)
    result: list[Card | None] = []
    if action == "shuffle_deck":
        deck.shuffle_deck()
    for _ in range(num_cards):
        result.append(deck.deal_card())
    print(f"預期：{expected}")
    print(f"實際：{result}")
    if result == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
