import subprocess
import sys
from pathlib import Path

from main_pokemon_go import RaidPokemon

TestCase = dict[str, str | int | bool]

run_cases: list[TestCase] = [
    {
        "pokemon1_name": "Pikachu",
        "pokemon1_stamina": 10,
        "pokemon1_charge_skill": 10,
        "pokemon2_name": "Eevee",
        "pokemon2_stamina": 8,
        "pokemon2_charge_skill": 8,
        "energy_cost": 50,
        "move_damage": 30,
        "expect_success": True,
        "expected_pokemon1_energy_after": 50,
        "expected_pokemon2_ready": True,
    },
    {
        "pokemon1_name": "Machamp",
        "pokemon1_stamina": 15,
        "pokemon1_charge_skill": 12,
        "pokemon2_name": "Snorlax",
        "pokemon2_stamina": 10,
        "pokemon2_charge_skill": 9,
        "energy_cost": 80,
        "move_damage": 50,
        "expect_success": True,
        "expected_pokemon1_energy_after": 40,
        "expected_pokemon2_ready": True,
    },
]

submit_cases: list[TestCase] = run_cases + [
    {
        "pokemon1_name": "Magikarp",
        "pokemon1_stamina": 5,
        "pokemon1_charge_skill": 1,
        "pokemon2_name": "Mewtwo",
        "pokemon2_stamina": 2,
        "pokemon2_charge_skill": 15,
        "energy_cost": 200,
        "move_damage": 400,
        "expect_success": False,
        "expected_pokemon1_energy_after": 10,
        "expected_pokemon2_ready": True,
    },
    {
        "pokemon1_name": "Lucario",
        "pokemon1_stamina": 5,
        "pokemon1_charge_skill": 7,
        "pokemon2_name": "Tyranitar",
        "pokemon2_stamina": 2,
        "pokemon2_charge_skill": 15,
        "energy_cost": 70,
        "move_damage": 400,
        "expect_success": True,
        "expected_pokemon1_energy_after": 0,
        "expected_pokemon2_ready": False,
    },
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(case: TestCase) -> bool:
    print("---------------------------------")
    pokemon1 = RaidPokemon(
        str(case["pokemon1_name"]),
        int(case["pokemon1_stamina"]),
        int(case["pokemon1_charge_skill"]),
    )
    pokemon2 = RaidPokemon(
        str(case["pokemon2_name"]),
        int(case["pokemon2_stamina"]),
        int(case["pokemon2_charge_skill"]),
    )
    print(
        f"{case['pokemon1_name']}（耐久：{case['pokemon1_stamina']}，熟練：{case['pokemon1_charge_skill']}）"
    )
    print(f"  起始 hp：{pokemon1.hp}")
    print(f"  起始能量：{pokemon1.energy}")
    print(
        f"{case['pokemon2_name']}（耐久：{case['pokemon2_stamina']}，熟練：{case['pokemon2_charge_skill']}）"
    )
    print(f"  起始 hp：{pokemon2.hp}")
    print(f"  起始能量：{pokemon2.energy}")
    print("")
    try:
        pokemon1.use_charged_move(
            pokemon2, int(case["energy_cost"]), int(case["move_damage"])
        )
        success = True
        print(f"{case['pokemon1_name']} 對 {case['pokemon2_name']} 使用蓄力招式...")
        print(f"  能量消耗：{case['energy_cost']}")
        print(f"  招式傷害：{case['move_damage']}")
        print("")
    except Exception as e:
        success = False
        print(f"例外：{e}")
    pokemon1_energy_after = pokemon1.energy
    pokemon2_ready_after = pokemon2.is_battle_ready()
    print(f"預期施放成功：{case['expect_success']}")
    print(f"實際施放成功：{success}")
    print(f"預期 {case['pokemon1_name']} 能量：{case['expected_pokemon1_energy_after']}")
    print(f"實際 {case['pokemon1_name']} 能量：{pokemon1_energy_after}")
    print(f"預期 {case['pokemon2_name']} 可戰鬥：{case['expected_pokemon2_ready']}")
    print(f"實際 {case['pokemon2_name']} 可戰鬥：{pokemon2_ready_after}")
    passed = (
        success == case["expect_success"]
        and pokemon1_energy_after == case["expected_pokemon1_energy_after"]
        and pokemon2_ready_after == case["expected_pokemon2_ready"]
    )
    if passed:
        print("通過")
    else:
        print("失敗")
    return passed


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
