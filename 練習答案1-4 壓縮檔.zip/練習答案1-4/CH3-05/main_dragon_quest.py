class SpellCaster:
    def __init__(self, name: str, stamina: int, wisdom: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__wisdom = wisdom
        self.mp = self.__wisdom * 10
        self.hp = self.__stamina * 100

    # 以上不能編輯

    def cast_fireball(
        self, target: "SpellCaster", fireball_cost: int, fireball_damage: int
    ) -> None:
        if self.mp < fireball_cost:
            raise Exception(f"{self.name} cannot cast fireball")
        self.mp -= fireball_cost
        target.get_fireballed(fireball_damage)

    def is_alive(self) -> bool:
        return self.hp > 0

    # 以下不能編輯

    def get_fireballed(self, fireball_damage: int) -> None:
        fireball_damage -= self.__stamina
        self.hp -= fireball_damage

    def drink_mp_potion(self, potion_mp: int) -> None:
        potion_mp += self.__wisdom
        self.mp += potion_mp
