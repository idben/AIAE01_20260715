# CH3-05 練習

## 題目

這一課練習封裝後的主動行為與例外處理。

- 《勇者鬥惡龍》版：完成 `cast_fireball()` 與 `is_alive()`
- 《寶可夢 GO》版：完成 `use_charged_move()` 與 `is_battle_ready()`

## 檔案

- `練習改寫/CH3-05/main_dragon_quest.py`
- `練習改寫/CH3-05/test_dragon_quest.py`
- `練習改寫/CH3-05/main_pokemon_go.py`
- `練習改寫/CH3-05/test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。全部通過時會播放過關音效。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成指定方法
4. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- 先觀察 `cast_fireball(target, fireball_cost, fireball_damage)` 的三個參數
- `target` 是被攻擊的目標物件，`fireball_cost` 是消耗，`fireball_damage` 是傷害
- 先檢查自己的 `mp` 是否足夠；不足時要丟出訊息格式為 `{名字} cannot cast fireball` 的 `Exception`
- 不足時不能先扣自己的 `mp`，也不能讓目標承受火球傷害
- `mp` 足夠時，才扣自己的 `mp`，並呼叫目標的受傷方法
- `is_alive()` 只需要回傳目前 `hp` 是否大於 `0`

### 《寶可夢 GO》版

- 先觀察 `use_charged_move(target, energy_cost, move_damage)` 的三個參數
- `target` 是被攻擊的目標物件，`energy_cost` 是消耗，`move_damage` 是傷害
- 先檢查自己的 `energy` 是否足夠；不足時要丟出訊息格式為 `{名字} cannot use charged move` 的 `Exception`
- 不足時不能先扣自己的 `energy`，也不能讓目標承受招式傷害
- `energy` 足夠時，才扣自己的 `energy`，並呼叫目標的受傷方法
- `is_battle_ready()` 只需要回傳目前 `hp` 是否大於 `0`

## 這題常見錯誤

- 先扣資源，才發現其實不夠
- 只拋出錯誤，卻沒有讓訊息符合題目
- 活著的判斷寫成 `>= 0`

## 這題在測什麼

- 是否能先檢查條件再執行行為
- 是否理解例外處理與狀態更新順序
- 是否能正確判斷角色或寶可夢還能不能戰鬥
