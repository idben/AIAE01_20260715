import subprocess
import sys
from pathlib import Path

from main_dragon_quest import SpellCaster

TestCase = dict[str, str | int | bool]

run_cases: list[TestCase] = [
    {
        "caster1_name": "勇者",
        "caster1_stamina": 10,
        "caster1_wisdom": 10,
        "caster2_name": "魔法使",
        "caster2_stamina": 8,
        "caster2_wisdom": 8,
        "fireball_cost": 50,
        "fireball_damage": 30,
        "expect_success": True,
        "expected_caster1_mp_after": 50,
        "expected_caster2_alive": True,
    },
    {
        "caster1_name": "賢者",
        "caster1_stamina": 15,
        "caster1_wisdom": 12,
        "caster2_name": "大魔導",
        "caster2_stamina": 10,
        "caster2_wisdom": 9,
        "fireball_cost": 80,
        "fireball_damage": 50,
        "expect_success": True,
        "expected_caster1_mp_after": 40,
        "expected_caster2_alive": True,
    },
]

submit_cases: list[TestCase] = run_cases + [
    {
        "caster1_name": "旅藝人",
        "caster1_stamina": 5,
        "caster1_wisdom": 1,
        "caster2_name": "竜王",
        "caster2_stamina": 2,
        "caster2_wisdom": 15,
        "fireball_cost": 200,
        "fireball_damage": 400,
        "expect_success": False,
        "expected_caster1_mp_after": 10,
        "expected_caster2_alive": True,
    },
    {
        "caster1_name": "僧侶",
        "caster1_stamina": 5,
        "caster1_wisdom": 7,
        "caster2_name": "ドラゴン",
        "caster2_stamina": 2,
        "caster2_wisdom": 15,
        "fireball_cost": 70,
        "fireball_damage": 400,
        "expect_success": True,
        "expected_caster1_mp_after": 0,
        "expected_caster2_alive": False,
    },
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(case: TestCase) -> bool:
    print("---------------------------------")
    caster1 = SpellCaster(
        str(case["caster1_name"]),
        int(case["caster1_stamina"]),
        int(case["caster1_wisdom"]),
    )
    caster2 = SpellCaster(
        str(case["caster2_name"]),
        int(case["caster2_stamina"]),
        int(case["caster2_wisdom"]),
    )
    print(
        f"{case['caster1_name']}（耐力：{case['caster1_stamina']}，智慧：{case['caster1_wisdom']}）"
    )
    print(f"  起始 hp：{caster1.hp}")
    print(f"  起始 mp：{caster1.mp}")
    print(
        f"{case['caster2_name']}（耐力：{case['caster2_stamina']}，智慧：{case['caster2_wisdom']}）"
    )
    print(f"  起始 hp：{caster2.hp}")
    print(f"  起始 mp：{caster2.mp}")
    print("")
    try:
        caster1.cast_fireball(
            caster2, int(case["fireball_cost"]), int(case["fireball_damage"])
        )
        success = True
        print(f"{case['caster1_name']} 對 {case['caster2_name']} 施放火球...")
        print(f"  火球消耗：{case['fireball_cost']}")
        print(f"  火球傷害：{case['fireball_damage']}")
        print("")
    except Exception as e:
        success = False
        print(f"例外：{e}")
    caster1_mp_after = caster1.mp
    caster2_alive_after = caster2.is_alive()
    print(f"預期施法成功：{case['expect_success']}")
    print(f"實際施法成功：{success}")
    print(f"預期 {case['caster1_name']} mp：{case['expected_caster1_mp_after']}")
    print(f"實際 {case['caster1_name']} mp：{caster1_mp_after}")
    print(f"預期 {case['caster2_name']} 存活：{case['expected_caster2_alive']}")
    print(f"實際 {case['caster2_name']} 存活：{caster2_alive_after}")
    passed = (
        success == case["expect_success"]
        and caster1_mp_after == case["expected_caster1_mp_after"]
        and caster2_alive_after == case["expected_caster2_alive"]
    )
    if passed:
        print("通過")
    else:
        print("失敗")
    return passed


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
