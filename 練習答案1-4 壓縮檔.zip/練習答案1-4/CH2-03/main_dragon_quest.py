class PartyMember:
    def get_turn_speed(self) -> int:
        return self.agility - self.armor_weight
