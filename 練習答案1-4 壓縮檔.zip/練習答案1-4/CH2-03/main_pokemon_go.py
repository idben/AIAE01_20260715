class PokemonBattleInfo:
    def get_attack_score(self) -> int:
        return self.attack + self.move_power
