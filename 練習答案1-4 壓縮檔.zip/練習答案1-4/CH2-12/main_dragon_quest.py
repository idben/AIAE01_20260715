class Item:
    def __init__(self, name: str, price: int) -> None:
        self.name = name
        self.price = price


class Shop:
    def __init__(self, name: str) -> None:
        self.name = name
        self.items: list[Item] = []

    def add_item(self, item: Item) -> None:
        self.items.append(item)

    def remove_item(self, item: Item) -> None:
        self.items = [
            current
            for current in self.items
            if current.name != item.name or current.price != item.price
        ]

    def search_items(self, search_string: str) -> list[Item]:
        return [item for item in self.items if search_string.lower() in item.name.lower()]
