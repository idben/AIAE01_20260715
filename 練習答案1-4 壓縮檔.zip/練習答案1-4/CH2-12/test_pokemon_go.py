import subprocess
import sys
from pathlib import Path

from main_pokemon_go import CaughtPokemon, CollectionBox

TestCase = tuple[str, list[str], list[int], CaughtPokemon, str, list[str]]

run_cases: list[TestCase] = [
    (
        "小智的收藏盒",
        ["Pikachu"],
        [321],
        CaughtPokemon("Pikachu", 321),
        "pika",
        [],
    ),
    (
        "小霞的收藏盒",
        ["Psyduck", "Staryu", "Magikarp"],
        [210, 450, 95],
        CaughtPokemon("Magikarp", 95),
        "star",
        ["Staryu"],
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        "小剛的收藏盒",
        ["Onix", "Geodude", "Graveler", "Zubat"],
        [900, 420, 820, 150],
        CaughtPokemon("Onix", 900),
        "geo",
        ["Geodude"],
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    owner_name: str,
    pokemon_names: list[str],
    pokemon_cps: list[int],
    pokemon_to_remove: CaughtPokemon,
    search_query: str,
    expected_search_results: list[str],
) -> bool:
    print("---------------------------------")
    try:
        box = CollectionBox(owner_name)
        for name, cp in zip(pokemon_names, pokemon_cps):
            box.add_pokemon(CaughtPokemon(name, cp))
            print(f"加入寶可夢 {name}，CP {cp}")
        box.remove_pokemon(pokemon_to_remove)
        results = box.search_pokemon(search_query)
        result_names = [pokemon.name for pokemon in results]
        print(f"預期：{expected_search_results}")
        print(f"實際：{result_names}")
        if result_names == expected_search_results:
            print("通過")
            return True
        print("失敗")
        return False
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
