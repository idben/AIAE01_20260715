class CaughtPokemon:
    def __init__(self, name: str, cp: int) -> None:
        self.name = name
        self.cp = cp


class CollectionBox:
    def __init__(self, owner_name: str) -> None:
        self.owner_name = owner_name
        self.pokemons: list[CaughtPokemon] = []

    def add_pokemon(self, pokemon: CaughtPokemon) -> None:
        self.pokemons.append(pokemon)

    def remove_pokemon(self, pokemon: CaughtPokemon) -> None:
        self.pokemons = [
            current
            for current in self.pokemons
            if current.name != pokemon.name or current.cp != pokemon.cp
        ]

    def search_pokemon(self, search_string: str) -> list[CaughtPokemon]:
        return [
            pokemon
            for pokemon in self.pokemons
            if search_string.lower() in pokemon.name.lower()
        ]
