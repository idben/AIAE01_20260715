import subprocess
import sys
from pathlib import Path

from main_pokemon_go import filter_active_nearby_spawns

TestCase = tuple[list[int], list[int]]

run_cases: list[TestCase] = [
    ([0, 20, 30], [20, 30]),
    ([10, 0, 40, 0], [10, 40]),
]

submit_cases: list[TestCase] = run_cases + [
    ([], []),
    ([3, 2, 0, 3, 0, 0], [3, 2, 3]),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(remaining_seconds_list: list[int], expected: list[int]) -> bool:
    print("---------------------------------")
    print(f"輸入：    {remaining_seconds_list}")
    print(f"預期：    {expected}")
    try:
        result = filter_active_nearby_spawns(remaining_seconds_list)
        print(f"實際：    {result}")
        return str(result) == str(expected)
    except Exception as e:
        print(f"錯誤：    {e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        correct = test(*test_case)
        if correct:
            passed += 1
            print("通過")
        else:
            failed += 1
            print("失敗")
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
