def remove_fainted_party_members(party_hps: list[int]) -> list[int]:
    active_party_hps: list[int] = []
    for party_hp in party_hps:
        if party_hp > 0:
            active_party_hps.append(party_hp)
    return active_party_hps
