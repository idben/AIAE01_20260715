def filter_active_nearby_spawns(nearby_spawn_timers: list[int]) -> list[int]:
    active_nearby_spawn_timers: list[int] = []
    for nearby_spawn_timer in nearby_spawn_timers:
        if nearby_spawn_timer > 0:
            active_nearby_spawn_timers.append(nearby_spawn_timer)
    return active_nearby_spawn_timers
