# CH1-01 練習

## 題目

這一課在改寫教材中有兩個例子，所以這個資料夾也拆成兩份練習：

- 《勇者鬥惡龍》版：把函式重新命名成測試要求的名稱，並讓它回傳一個新串列，只保留還有血量的隊伍成員
- 《寶可夢 GO (Pokemon GO)》版：把函式重新命名成測試要求的名稱，並讓它回傳一個新串列，只保留仍在附近出現中的寶可夢資料

## 檔案

- `main_dragon_quest.py`：學生作答，《勇者鬥惡龍》版
- `test_dragon_quest.py`：執行驗證，《勇者鬥惡龍》版
- `main_pokemon_go.py`：學生作答，《寶可夢 GO (Pokemon GO)》版
- `test_pokemon_go.py`：執行驗證，《寶可夢 GO (Pokemon GO)》版

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開 `test_dragon_quest.py` 或 `test_pokemon_go.py`，再按播放鍵執行。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 依照題目修改函式名稱與內容
4. 存檔後，在這個資料夾執行對應測試：

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。

5. 觀察每一筆測試的 `Expected` 和 `Actual`
6. 如果最後看到 `============= PASS ==============`
   代表該版本已通過目前測試

## 題目提示

### 《勇者鬥惡龍》版

- 測試會匯入 `remove_fainted_party_members`
- 輸入是隊伍血量清單
- 要回傳過濾後的新清單，只保留大於 `0` 的值

### 《寶可夢 GO (Pokemon GO)》版

- 測試會匯入 `filter_active_nearby_spawns`
- 輸入是附近出現資料中的剩餘秒數清單
- 要回傳過濾後的新清單，只保留大於 `0` 的值

## 這題常見錯誤

- `ImportError`
  代表你還沒有把函式改成測試要求的名稱

- `Actual` 和 `Expected` 不同
  代表你過濾血量的邏輯還不正確

## 這題在測什麼

- 函式名稱是否正確
- 是否能處理整組資料清單
- 是否只保留大於 `0` 的值
