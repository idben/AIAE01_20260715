class PartyMember:
    def __init__(self, name: str, hp: int) -> None:
        self.name = name
        self.hp = hp

    def get_status(self) -> tuple[str, int]:
        return self.name, self.hp
