# CH2-11 練習

## 題目

這一課練習把類別變數 (Class Variable) 改成實例變數 (Instance Variable)。

- 《勇者鬥惡龍》版：修正 `PartyMember`
- 《寶可夢 GO》版：修正 `Encounter`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 移除類別變數，改用建構子設定實例變數
4. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- 每個角色的血量都應該各自保存，不應共享
- `PartyMember.hp = 20` 不應該影響已建立的角色
- `__init__()` 要設定 `self.name` 和 `self.hp`

### 《寶可夢 GO》版

- 每次遭遇的球數都應該各自保存，不應共享
- `Encounter.poke_balls = 0` 不應該影響已建立的遭遇
- `__init__()` 要設定 `self.pokemon_name` 和 `self.poke_balls`

## 這題常見錯誤

- 只在建構子裡設定名稱，忘了設定真正要獨立保存的數值
- 沒有移除類別變數，導致共享狀態還在

## 這題在測什麼

- 是否理解類別變數和實例變數的差別
- 是否能避免共享狀態造成的副作用
