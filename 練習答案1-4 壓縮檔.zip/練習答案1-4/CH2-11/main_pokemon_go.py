class Encounter:
    def __init__(self, pokemon_name: str, poke_balls: int) -> None:
        self.pokemon_name = pokemon_name
        self.poke_balls = poke_balls

    def get_status(self) -> tuple[str, int]:
        return self.pokemon_name, self.poke_balls
