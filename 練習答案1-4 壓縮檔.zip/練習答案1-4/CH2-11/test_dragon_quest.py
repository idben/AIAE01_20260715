import subprocess
import sys
from pathlib import Path

from main_dragon_quest import PartyMember

TestCase = tuple[str, str, int, int]

run_cases: list[TestCase] = [
    ("勇者", "僧侶", 30, 22),
]

submit_cases: list[TestCase] = run_cases + [
    ("魔法使", "戰士", 18, 34),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    first_name: str,
    second_name: str,
    first_hp: int,
    second_hp: int,
) -> bool:
    print("---------------------------------")
    try:
        first_member = PartyMember(first_name, first_hp)
        second_member = PartyMember(second_name, second_hp)
        PartyMember.hp = 1
        print(f"預期 {first_name} HP：{first_hp}")
        print(f"實際 {first_name} HP：{first_member.hp}")
        print(f"預期 {second_name} HP：{second_hp}")
        print(f"實際 {second_name} HP：{second_member.hp}")
        passed = first_member.hp == first_hp and second_member.hp == second_hp
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
