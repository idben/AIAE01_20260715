import subprocess
import sys
from pathlib import Path

from main_pokemon_go import Encounter

TestCase = tuple[str, str, int, int]

run_cases: list[TestCase] = [
    ("Pikachu", "Eevee", 3, 5),
]

submit_cases: list[TestCase] = run_cases + [
    ("Snorlax", "Bulbasaur", 10, 2),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    first_name: str,
    second_name: str,
    first_balls: int,
    second_balls: int,
) -> bool:
    print("---------------------------------")
    try:
        first_encounter = Encounter(first_name, first_balls)
        second_encounter = Encounter(second_name, second_balls)
        Encounter.poke_balls = 0
        print(f"預期 {first_name} 球數：{first_balls}")
        print(f"實際 {first_name} 球數：{first_encounter.poke_balls}")
        print(f"預期 {second_name} 球數：{second_balls}")
        print(f"實際 {second_name} 球數：{second_encounter.poke_balls}")
        passed = (
            first_encounter.poke_balls == first_balls
            and second_encounter.poke_balls == second_balls
        )
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
