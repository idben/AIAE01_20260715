class GoldVault:
    def __init__(self, vault_id: str, initial_gold: float) -> None:
        self.__vault_id = vault_id
        self.__gold = initial_gold

    def get_vault_id(self) -> str:
        return self.__vault_id

    def get_gold(self) -> float:
        return self.__gold

    def deposit_gold(self, amount: float) -> None:
        if amount <= 0:
            raise ValueError("cannot deposit zero or negative funds")
        self.__gold += amount

    def withdraw_gold(self, amount: float) -> None:
        if amount <= 0:
            raise ValueError("cannot withdraw zero or negative funds")
        if amount > self.__gold:
            raise ValueError("insufficient funds")
        self.__gold -= amount
