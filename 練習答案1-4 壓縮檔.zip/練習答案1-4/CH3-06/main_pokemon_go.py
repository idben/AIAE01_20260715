class CoinWallet:
    def __init__(self, trainer_id: str, initial_coins: float) -> None:
        self.__trainer_id = trainer_id
        self.__coins = initial_coins

    def get_trainer_id(self) -> str:
        return self.__trainer_id

    def get_coins(self) -> float:
        return self.__coins

    def earn_coins(self, amount: float) -> None:
        if amount <= 0:
            raise ValueError("cannot deposit zero or negative funds")
        self.__coins += amount

    def spend_coins(self, amount: float) -> None:
        if amount <= 0:
            raise ValueError("cannot withdraw zero or negative funds")
        if amount > self.__coins:
            raise ValueError("insufficient funds")
        self.__coins -= amount
