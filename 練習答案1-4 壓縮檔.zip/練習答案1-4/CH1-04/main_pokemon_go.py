Pokemon = dict[str, int]


def get_pokemon_dps(pokemon: Pokemon) -> int:
    return pokemon["damage"] * pokemon["attacks_per_second"]


def fight_pokemon(pokemon_one: Pokemon, pokemon_two: Pokemon) -> str:
    pokemon_one_dps = get_pokemon_dps(pokemon_one)
    pokemon_two_dps = get_pokemon_dps(pokemon_two)
    if pokemon_one_dps > pokemon_two_dps:
        return "pokemon 1 wins"
    if pokemon_two_dps > pokemon_one_dps:
        return "pokemon 2 wins"
    return "both faint"
