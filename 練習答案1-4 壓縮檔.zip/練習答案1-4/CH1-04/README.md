# CH1-04 練習

## 題目

請把重複的計算邏輯抽成函式，並在主函式中使用它。

這一題對應改寫教材中的雙例子：
- 《寶可夢 GO (Pokemon GO)》：`get_pokemon_dps`
- 《勇者鬥惡龍》：`get_spell_mp_cost`

## 檔案

- `main_pokemon_go.py`：學生作答，《寶可夢 GO (Pokemon GO)》版
- `test_pokemon_go.py`：執行驗證，《寶可夢 GO (Pokemon GO)》版
- `main_dragon_quest.py`：學生作答，《勇者鬥惡龍》版
- `test_dragon_quest.py`：執行驗證，《勇者鬥惡龍》版

## 執行方式

```bash
python3 test_pokemon_go.py
python3 test_dragon_quest.py
```

也可以直接打開 `test_pokemon_go.py` 或 `test_dragon_quest.py`，再按播放鍵執行。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 新增題目要求的共用函式
4. 把主函式中的重複計算改成呼叫這個函式
5. 存檔後，在這個資料夾執行對應測試：

```bash
python3 test_pokemon_go.py
python3 test_dragon_quest.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。

6. 如果最後看到 `============= 全部通過 ==============`
   代表該版本已通過目前測試

## 題目提示

### 《寶可夢 GO (Pokemon GO)》版

- 測試會同時驗證 `fight_pokemon` 與 `get_pokemon_dps`
- `get_pokemon_dps` 必須回傳 `damage * attacks_per_second`

### 《勇者鬥惡龍》版

- 測試會同時驗證 `compare_spells` 與 `get_spell_mp_cost`
- `get_spell_mp_cost` 必須回傳 `base_cost + level_scale`

## 這題常見錯誤

- `ImportError`
  代表你還沒有建立測試要求的函式

- 勝負結果正確，但測試還是失敗
  代表你可能直接把結果算在主函式裡，卻沒有真的把重複邏輯抽成共用函式

## 這題在測什麼

- 主函式是否能正確判斷結果
- 共用函式是否存在
- 共用函式是否真的正確計算指定公式
