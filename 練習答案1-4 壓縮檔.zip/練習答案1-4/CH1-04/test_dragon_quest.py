import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Spell, compare_spells, get_spell_mp_cost

TestCase = tuple[Spell, Spell, str]

run_cases: list[TestCase] = [
    (
        {"base_cost": 5, "level_scale": 2},
        {"base_cost": 7, "level_scale": 3},
        "spell 1 costs less",
    ),
    (
        {"base_cost": 10, "level_scale": 5},
        {"base_cost": 6, "level_scale": 1},
        "spell 2 costs less",
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        {"base_cost": 3, "level_scale": 3},
        {"base_cost": 2, "level_scale": 4},
        "both spells cost the same",
    ),
    (
        {"base_cost": 1, "level_scale": 8},
        {"base_cost": 4, "level_scale": 6},
        "spell 1 costs less",
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(spell_one: Spell, spell_two: Spell, expected: str) -> bool:
    print("---------------------------------")
    print(f"咒文一：  {spell_one}")
    print(f"咒文二：  {spell_two}")
    print(f"預期：    {expected}")
    try:
        result = compare_spells(spell_one, spell_two)
        print(f"實際：    {result}")
        if result != expected:
            print("失敗")
            return False
        actual_one = get_spell_mp_cost(spell_one)
        actual_two = get_spell_mp_cost(spell_two)
        expected_one = spell_one["base_cost"] + spell_one["level_scale"]
        expected_two = spell_two["base_cost"] + spell_two["level_scale"]
        if actual_one != expected_one:
            print(f"預期的咒文一消耗：{expected_one}")
            print(f"實際的咒文一消耗：{actual_one}")
            return False
        if actual_two != expected_two:
            print(f"預期的咒文二消耗：{expected_two}")
            print(f"實際的咒文二消耗：{actual_two}")
            return False
        print("通過")
        return True
    except Exception as e:
        print(f"錯誤：    {e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        correct = test(*test_case)
        if correct:
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
