Spell = dict[str, int]


def get_spell_mp_cost(spell: Spell) -> int:
    return spell["base_cost"] + spell["level_scale"]


def compare_spells(spell_one: Spell, spell_two: Spell) -> str:
    spell_one_mp_cost = get_spell_mp_cost(spell_one)
    spell_two_mp_cost = get_spell_mp_cost(spell_two)
    if spell_one_mp_cost < spell_two_mp_cost:
        return "spell 1 costs less"
    if spell_two_mp_cost < spell_one_mp_cost:
        return "spell 2 costs less"
    return "both spells cost the same"
