# CH3-03 練習

## 題目

這一課練習讓物件 (Object) 自己更新狀態。

- 《勇者鬥惡龍》版：完成 `SpellCaster.get_fireballed()` 與 `SpellCaster.drink_mp_potion()`
- 《寶可夢 GO》版：完成 `RaidPokemon.take_charged_hit()` 與 `RaidPokemon.use_energy_booster()`

## 檔案

- `練習改寫/CH3-03/main_dragon_quest.py`
- `練習改寫/CH3-03/test_dragon_quest.py`
- `練習改寫/CH3-03/main_pokemon_go.py`
- `練習改寫/CH3-03/test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。全部通過時會播放過關音效。

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 完成指定方法
4. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- 先觀察建構子已經存了哪些資料：名稱、耐力、智慧、目前 `hp`、目前 `mp`
- `get_fireballed()` 收到原始火球傷害，會更新自己的 `hp`
- `drink_mp_potion()` 收到原始藥水回復量，會更新自己的 `mp`
- 火球傷害不是直接扣到 `hp`，耐力會先抵掉一部分傷害，剩下的傷害才扣到 `hp`
- 藥水回復量不是直接加到 `mp`，智慧會先讓回復量增加，修正後才加到 `mp`
- 實作前先判斷：哪個內部資料用來修正傷害？哪個內部資料用來修正回復量？

### 《寶可夢 GO》版

- 先觀察建構子已經存了哪些資料：名稱、耐久、蓄力熟練、目前 `hp`、目前 `energy`
- `take_charged_hit()` 收到原始蓄力招式傷害，會更新自己的 `hp`
- `use_energy_booster()` 收到原始能量補充量，會更新自己的 `energy`
- 蓄力招式傷害不是直接扣到 `hp`，耐久會先抵掉一部分傷害，剩下的傷害才扣到 `hp`
- 能量補充量不是直接加到 `energy`，蓄力熟練會先讓補充量增加，修正後才加到 `energy`
- 實作前先判斷：哪個內部資料用來修正傷害？哪個內部資料用來修正補充量？

## 這題常見錯誤

- 有算出新數值，但沒有真的存回屬性
- 把加減順序寫反
- 直接回傳數值，卻沒有修改物件狀態

## 這題在測什麼

- 是否理解方法直接修改物件狀態
- 是否能使用私有屬性參與計算
- 是否能正確更新公開屬性
