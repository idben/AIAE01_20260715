class RaidPokemon:
    def __init__(self, name: str, stamina: int, charge_skill: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__charge_skill = charge_skill
        self.hp = stamina * 100
        self.energy = charge_skill * 10

    def take_charged_hit(self, charged_damage: int) -> None:
        self.hp -= max(charged_damage - self.__stamina, 0)

    def use_energy_booster(self, booster_energy: int) -> None:
        self.energy += booster_energy + self.__charge_skill
