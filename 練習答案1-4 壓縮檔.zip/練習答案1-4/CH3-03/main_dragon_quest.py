class SpellCaster:
    def __init__(self, name: str, stamina: int, wisdom: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__wisdom = wisdom
        self.hp = stamina * 100
        self.mp = wisdom * 10

    def get_fireballed(self, fireball_damage: int) -> None:
        self.hp -= max(fireball_damage - self.__stamina, 0)

    def drink_mp_potion(self, potion_mp: int) -> None:
        self.mp += potion_mp + self.__wisdom
