# CH2-08 練習

## 題目

這一課練習建立多個物件，並把它們傳進同一個函式中比較。

- 《勇者鬥惡龍》版：在 `main_dragon_quest.py` 的 `main()` 中建立四位隊友，並呼叫兩次 `compare_party_members()`
- 《寶可夢 GO》版：在 `main_pokemon_go.py` 的 `main()` 中建立四個附近出現，並呼叫兩次 `compare_spawns()`

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 學生操作步驟

1. 先選一個版本練習
2. 打開對應的 `main_*.py`
3. 在 `main()` 中建立四個物件
4. 呼叫兩次比較函式
5. 存檔後執行對應測試

## 題目提示

### 《勇者鬥惡龍》版

- 這題重點是建立多個彼此獨立的隊友物件
- 你可以用像 `hero`、`priest`、`mage`、`warrior` 這種變數名稱
- 你可以直接參考這個表：

| 變數名稱 | name | hp | mp |
| --- | --- | --- | --- |
| `hero` | `"勇者"` | `30` | `10` |
| `priest` | `"僧侶"` | `22` | `18` |
| `mage` | `"魔法使"` | `18` | `24` |
| `warrior` | `"戰士"` | `34` | `6` |

- 依序呼叫：
  - `compare_party_members(hero, priest)`
  - `compare_party_members(mage, warrior)`

### 《寶可夢 GO》版

- 這題重點是建立多個彼此獨立的附近出現資料
- 你可以用像 `pikachu`、`eevee`、`snorlax`、`bulbasaur` 這種變數名稱
- 你可以直接參考這個表：

| 變數名稱 | name | cp | remaining_seconds |
| --- | --- | --- | --- |
| `pikachu` | `"Pikachu"` | `321` | `180` |
| `eevee` | `"Eevee"` | `280` | `95` |
| `snorlax` | `"Snorlax"` | `2044` | `240` |
| `bulbasaur` | `"Bulbasaur"` | `140` | `90` |

- 依序呼叫：
  - `compare_spawns(pikachu, eevee)`
  - `compare_spawns(snorlax, bulbasaur)`

## 這題常見錯誤

- 建立了物件，但忘了呼叫比較函式
- 變數命名只有編號，導致容易搞混
- 對戰或比較順序寫反

## 這題在測什麼

- 是否能建立多個獨立物件
- 是否能把不同物件當參數傳進同一個函式
- 命名是否清楚、資料是否正確
