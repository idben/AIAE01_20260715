class PokemonSpawn:
    def __init__(self, name: str, cp: int, remaining_seconds: int) -> None:
        self.name = name
        self.cp = cp
        self.remaining_seconds = remaining_seconds

    def get_priority(self) -> int:
        return self.cp + self.remaining_seconds


def main() -> None:
    cases = [
        (PokemonSpawn("Pikachu", 321, 180), PokemonSpawn("Eevee", 280, 95)),
        (PokemonSpawn("Snorlax", 2044, 240), PokemonSpawn("Bulbasaur", 140, 90)),
    ]
    for first, second in cases:
        print(f"{first.name}: {first.get_priority()} priority")
        print(f"{second.name}: {second.get_priority()} priority")
        if first.get_priority() >= second.get_priority():
            print(f"{first.name} first!")
        else:
            print(f"{second.name} first!")
        print("---------------------------------")
