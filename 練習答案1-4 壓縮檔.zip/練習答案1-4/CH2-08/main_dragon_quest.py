class PartyMember:
    def __init__(self, name: str, hp: int, mp: int) -> None:
        self.name = name
        self.hp = hp
        self.mp = mp

    def get_support(self) -> int:
        return self.hp + self.mp


def main() -> None:
    cases = [
        (PartyMember("勇者", 30, 10), PartyMember("僧侶", 22, 18)),
        (PartyMember("魔法使", 18, 24), PartyMember("戰士", 34, 6)),
    ]
    for first, second in cases:
        print(f"{first.name}: {first.get_support()} support")
        print(f"{second.name}: {second.get_support()} support")
        if first.get_support() > second.get_support():
            print(f"{first.name} wins!")
        elif second.get_support() > first.get_support():
            print(f"{second.name} wins!")
        else:
            print("It's a tie!")
        print("---------------------------------")
