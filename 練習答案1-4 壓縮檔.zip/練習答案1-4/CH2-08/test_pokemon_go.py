import subprocess
import sys
from pathlib import Path

from contextlib import redirect_stdout
from io import StringIO

from main_pokemon_go import main

run_expected = """Pikachu: 501 priority
Eevee: 375 priority
Pikachu first!
---------------------------------
Snorlax: 2284 priority
Bulbasaur: 230 priority
Snorlax first!
---------------------------------
"""


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test() -> bool:
    print("---------------------------------")
    print("執行 main() 並檢查輸出")
    buffer = StringIO()
    try:
        with redirect_stdout(buffer):
            main()
    except Exception as e:
        print(f"錯誤：{e}")
        return False
    actual = buffer.getvalue()
    print("預期輸出：")
    print(run_expected, end="")
    print("實際輸出：")
    print(actual, end="")
    if actual == run_expected:
        print("通過")
        return True
    print("失敗")
    return False


def main_test() -> None:
    if test():
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")


main_test()
