class ItemBag:
    def use_poke_ball(self) -> None:
        self.poke_balls -= 1
