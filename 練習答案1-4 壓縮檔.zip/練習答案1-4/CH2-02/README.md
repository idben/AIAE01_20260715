# CH2-02 練習

## 題目

這一課練習方法 (Method) 直接修改物件狀態。

先看《勇者鬥惡龍》版。

隊伍成員 (Party Member) 會記住自己的血量，你可以用 `hp` 當作變數名稱。當角色受到傷害時，`take_damage()` 應該讓這個物件自己的 `hp` 減去輸入的 `damage`。

完成後，再做《寶可夢 GO》版。

背包 (Item Bag) 會記住自己目前有幾顆球，你可以用 `poke_balls` 當作變數名稱。當 `use_poke_ball()` 被呼叫時，應該讓這個物件自己的 `poke_balls` 減少 `1`。

## 檔案

- `main_dragon_quest.py`：學生作答，《勇者鬥惡龍》版
- `test_dragon_quest.py`：執行驗證，《勇者鬥惡龍》版
- `main_pokemon_go.py`：學生作答，《寶可夢 GO》版
- `test_pokemon_go.py`：執行驗證，《寶可夢 GO》版

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

也可以直接打開對應的 `test_*.py`，再按播放鍵執行。

## 學生操作步驟

1. 先打開 `main_dragon_quest.py`
2. 找到 `PartyMember.take_damage()`
3. 把角色自己的 `hp` 減去輸入的 `damage`
4. 存檔後，先執行：

```bash
python3 test_dragon_quest.py
```

5. 《勇者鬥惡龍》版通過後，再打開 `main_pokemon_go.py`
6. 找到 `ItemBag.use_poke_ball()`
7. 把背包自己的 `poke_balls` 減少 `1`
8. 存檔後，在這個資料夾執行對應測試
9. 如果最後看到 `============= 全部通過 ==============`
   代表該版本已通過目前測試

## 題目提示

### 《勇者鬥惡龍》版

- 角色有血量，你可以用 `hp` 來記
- `take_damage()` 收到 `damage` 後，要更新這個物件自己的 `hp`

### 《寶可夢 GO》版

- 背包有球數，你可以用 `poke_balls` 來記
- `use_poke_ball()` 被呼叫後，要更新這個物件自己的 `poke_balls`

## 這題常見錯誤

- 方法有寫出來，但沒有真的改到 `self` 上的屬性
- 把結果 `return` 出去，但物件狀態沒有更新

## 這題在測什麼

- 方法是否存在
- 是否真的改到物件狀態
- 是否理解 `self` 代表目前物件
