import subprocess
import sys
from pathlib import Path

from main_dragon_quest import PartyMember

TestCase = tuple[int, int, int]

run_cases: list[TestCase] = [
    (20, 5, 15),
    (14, 4, 10),
]

submit_cases: list[TestCase] = run_cases + [
    (30, 10, 20),
    (3, 2, 1),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(hp: int, damage: int, expected: int) -> bool:
    print("---------------------------------")
    print(f"輸入 HP：{hp}")
    print(f"輸入傷害：{damage}")
    print(f"預期 HP：{expected}")
    member = PartyMember()
    member.hp = hp
    member.take_damage(damage)
    result = member.hp
    print(f"實際 HP：{result}")
    if result == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
