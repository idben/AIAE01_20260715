class PartyMember:
    def take_damage(self, damage: int) -> None:
        self.hp -= damage
