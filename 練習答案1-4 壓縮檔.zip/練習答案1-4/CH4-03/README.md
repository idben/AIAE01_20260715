# CH4-03 練習

## 題目

這一課把「先檢查資源、成功後才套用加成」的規則包成方法。

- 《勇者鬥惡龍》版：完成 `PartyMember` 的衝刺移動
- 《寶可夢 GO》版：完成 `EggIncubator` 的加速孵蛋

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 《勇者鬥惡龍》操作步驟

1. 先看 `PartyMember` 會記住哪些資料：`pos_x`、`pos_y`、`speed`、`stamina`
2. 再看 `sprint_right()`、`sprint_left()`、`sprint_up()`、`sprint_down()`：這些方法都不另外收參數，方向已經寫在方法名稱裡
3. 先完成 `__raise_if_cannot_sprint()`：`stamina` 小於等於 `0` 時丟出 `not enough stamina to sprint`，而且不要改變位置或資源
4. 再完成 `__use_sprint_stamina()`：只在衝刺成功時扣 `stamina`
5. 最後完成四個 `sprint_*()` 方法：每次衝刺都要先檢查、再扣資源、再朝同方向做兩次一般移動
6. 執行 `python3 test_dragon_quest.py` 確認結果

## 《寶可夢 GO》操作步驟

1. 先看 `EggIncubator` 會記住哪些資料：`egg_km`、`walked_km`、`boost_charges`
2. 再看 `boost_walk(km)`：參數 `km` 代表這次實際走了幾公里
3. 先完成 `__raise_if_no_boost()`：`boost_charges` 小於等於 `0` 時丟出 `no boost charges left`，而且不要改變進度或資源
4. 再完成 `__use_boost_charge()`：只在加速成功時扣 `boost_charges`
5. 最後完成 `boost_walk(km)`：每次加速都要先檢查、再扣資源、再把這次走路距離以加倍方式計入進度
6. 執行 `python3 test_pokemon_go.py` 確認結果

## 題目提示

- 衝刺改到的是自己這個物件的位置與資源，不會改到其他物件
- 衝刺是一次性的動作，不是把 `speed` 永久改成兩倍
- 資源不足時要立刻停止，不能先扣資源，也不能先移動
- 《寶可夢 GO》版的加速孵蛋也是一次性的動作，不是永久改變蛋需要的公里數
- 測試會檢查錯誤訊息是否完全等於 `not enough stamina to sprint` 或 `no boost charges left`

## 常見錯誤

- 把 `speed` 永久改成兩倍
- 先移動才檢查體力
- 忘記扣除一次體力
- 只移動一次
- 資源不足時沒有丟出 `not enough stamina to sprint`
- 《寶可夢 GO》版資源不足時沒有丟出 `no boost charges left`
- 《寶可夢 GO》版把 `boost_charges` 扣成負數，或失敗時先增加了孵蛋進度

## 這題在測什麼

- 私有方法與公開方法的分工
- 狀態更新順序
- 例外訊息檢查
