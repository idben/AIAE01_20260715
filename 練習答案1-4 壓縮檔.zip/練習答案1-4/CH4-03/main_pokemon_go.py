class EggIncubator:
    def boost_walk(self, km: float) -> None:
        self.__raise_if_no_boost()
        self.__use_boost_charge()
        self.walk(km * 2)

    def __raise_if_no_boost(self) -> None:
        if self.__boost_charges <= 0:
            raise Exception("no boost charges left")

    def __use_boost_charge(self) -> None:
        self.__boost_charges -= 1

    def walk(self, km: float) -> None:
        self.__walked_km += km

    def get_remaining_distance(self) -> float:
        remaining = self.__egg_km - self.__walked_km
        if remaining < 0:
            return 0.0
        return remaining

    def is_ready_to_hatch(self) -> bool:
        return self.get_remaining_distance() == 0

    def __init__(self, egg_km: float, boost_charges: int) -> None:
        self.__egg_km = egg_km
        self.__walked_km = 0.0
        self.__boost_charges = boost_charges
