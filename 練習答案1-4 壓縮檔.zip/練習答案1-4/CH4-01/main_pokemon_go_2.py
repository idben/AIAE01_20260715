class EggIncubator:
    def __init__(self, egg_km: float) -> None:
        self.__egg_km = egg_km
        self.__walked_km = 0.0

    def walk(self, km: float) -> None:
        self.__walked_km += km

    def get_remaining_distance(self) -> float:
        if self.__walked_km >= self.__egg_km:
            return 0.0
        return self.__egg_km - self.__walked_km

    def is_ready_to_hatch(self) -> bool:
        return self.__walked_km >= self.__egg_km
