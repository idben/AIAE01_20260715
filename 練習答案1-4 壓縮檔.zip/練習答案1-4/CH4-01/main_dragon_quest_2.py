class PartyMember:
    def __init__(self, pos_x: int, pos_y: int, speed: int) -> None:
        self.__pos_x = pos_x
        self.__pos_y = pos_y
        self.__speed = speed

    def move_right(self) -> None:
        self.__move(dx=self.__speed, dy=0)

    def move_left(self) -> None:
        self.__move(dx=-self.__speed, dy=0)

    def move_up(self) -> None:
        self.__move(dx=0, dy=self.__speed)

    def move_down(self) -> None:
        self.__move(dx=0, dy=-self.__speed)

    def get_position(self) -> tuple[int, int]:
        return self.__pos_x, self.__pos_y

    def __move(self, dx: int, dy: int) -> None:
        self.__pos_x += dx
        self.__pos_y += dy
