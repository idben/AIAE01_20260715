import subprocess
import sys
from pathlib import Path

from main_dragon_quest import PartyMember

TestCase = tuple[int, int, int, str, int, int]

run_cases: list[TestCase] = [
    (0, 0, 4, "right", 4, 0),
    (2, 3, 2, "up", 2, 5),
]

submit_cases: list[TestCase] = run_cases + [
    (5, 5, 3, "left", 2, 5),
    (1, 1, 6, "down", 1, -5),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    pos_x: int,
    pos_y: int,
    speed: int,
    move_direction: str,
    expected_x: int,
    expected_y: int,
) -> bool:
    print("---------------------------------")
    member = PartyMember(pos_x, pos_y, speed)
    if move_direction == "left":
        member.move_left()
    elif move_direction == "right":
        member.move_right()
    elif move_direction == "up":
        member.move_up()
    elif move_direction == "down":
        member.move_down()
    actual = member.get_position()
    expected = (expected_x, expected_y)
    print(f"預期：{expected}")
    print(f"實際：{actual}")
    if actual == expected:
        print("通過")
        return True
    print("失敗")
    return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for case in test_cases:
        if test(*case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
