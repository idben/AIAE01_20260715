class EggIncubator:
    def __init__(self, egg_km: float) -> None:
        self.__egg_km = egg_km
        self.__walked_km = 0.0

    def walk(self, km: float) -> None:
        updated_distance = self.__walked_km + km
        self.__walked_km = updated_distance

    def get_remaining_distance(self) -> float:
        remaining = self.__egg_km - self.__walked_km
        return max(0.0, remaining)

    def is_ready_to_hatch(self) -> bool:
        remaining = self.get_remaining_distance()
        return remaining == 0.0
