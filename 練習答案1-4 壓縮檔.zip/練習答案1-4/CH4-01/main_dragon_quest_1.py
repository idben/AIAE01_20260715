class PartyMember:
    def __init__(self, pos_x: int, pos_y: int, speed: int) -> None:
        self.__pos_x = pos_x
        self.__pos_y = pos_y
        self.__speed = speed

    def move_right(self) -> None:
        next_x = self.__pos_x + self.__speed
        self.__pos_x = next_x

    def move_left(self) -> None:
        next_x = self.__pos_x - self.__speed
        self.__pos_x = next_x

    def move_up(self) -> None:
        next_y = self.__pos_y + self.__speed
        self.__pos_y = next_y

    def move_down(self) -> None:
        next_y = self.__pos_y - self.__speed
        self.__pos_y = next_y

    def get_position(self) -> tuple[int, int]:
        current_position = (self.__pos_x, self.__pos_y)
        return current_position
