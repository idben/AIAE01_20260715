# CH4-01 練習

## 題目

這一課練習把常用規則包成方法。

- 《勇者鬥惡龍》版：完成 `PartyMember` 的上下左右移動
- 《寶可夢 GO》版：完成 `EggIncubator` 的走路孵蛋進度

## 檔案

- `main_dragon_quest.py`
- `test_dragon_quest.py`
- `main_pokemon_go.py`
- `test_pokemon_go.py`

## 執行方式

```bash
python3 test_dragon_quest.py
python3 test_pokemon_go.py
```

## 《勇者鬥惡龍》操作步驟

1. 先看 `PartyMember` 會記住哪些資料：`pos_x`、`pos_y`、`speed`
2. 再看四個 `move_*()` 方法：它們都不另外收參數，方向已經寫在方法名稱裡
3. 判斷每個方向應該改變水平位置還是垂直位置
4. 判斷這個方向是增加座標還是減少座標，每次改變的距離都由 `speed` 決定
5. 完成 `get_position()`：它不改位置，只回傳目前的 `(x, y)` tuple
6. 執行 `python3 test_dragon_quest.py` 確認結果

## 《寶可夢 GO》操作步驟

1. 先看 `EggIncubator` 會記住哪些資料：`egg_km`、`walked_km`
2. 再看 `walk(km)`：參數 `km` 代表這次實際走了幾公里
3. 判斷 `walk(km)` 應該更新哪一個內部資料
4. 完成 `get_remaining_distance()`：剩餘距離不能低於 `0`
5. 完成 `is_ready_to_hatch()`：剩餘距離是 `0.0` 時回傳 `True`，還大於 `0.0` 時回傳 `False`
6. 執行 `python3 test_pokemon_go.py` 確認結果

## 《勇者鬥惡龍》題目提示

- 《勇者鬥惡龍》版的 `PartyMember` 表示迷宮中的隊伍成員
- 四個 `move_*()` 方法改到的是自己這個物件，不會改到其他角色
- `pos_x` 表示水平位置，`pos_y` 表示垂直位置
- 測試會用 `get_position()` 的回傳值確認移動結果

## 《寶可夢 GO》題目提示

- 《寶可夢 GO》版的 `EggIncubator` 表示一顆正在累積走路距離的孵蛋器
- `walk(km)` 改到的是這個孵蛋器自己的 `walked_km`
- `get_remaining_distance()` 只回傳剩餘距離，不應該改變走路進度
- `is_ready_to_hatch()` 只判斷是否可以孵化，不應該改變走路進度

## 常見錯誤

- 左右或上下方向加減寫反
- `get_position()` 沒回傳 `(x, y)`
- 忘了使用 `self.__speed`
- 《寶可夢 GO》版讓剩餘距離變成負數
- 《寶可夢 GO》版在 `is_ready_to_hatch()` 改了進度

## 這題在測什麼

- 物件狀態更新
- 私有屬性的讀寫
- 以方法包裝移動邏輯
