import subprocess
import sys
from pathlib import Path

from main_dragon_quest import Caster

ExpectedResult = list[tuple[int, int] | None]
TestCase = tuple[Caster, Caster, int, ExpectedResult, str | None]

run_cases: list[TestCase] = [
    (
        Caster("勇者", 6, 2),
        Caster("魔法使", 3, 4),
        1,
        [(5, 1), (2, 3)],
        None,
    ),
    (
        Caster("僧侶", 1, 0),
        Caster("史萊姆", 1, 0),
        1,
        [None, None],
        "僧侶 can't cast",
    ),
]

submit_cases: list[TestCase] = run_cases + [
    (
        Caster("戰士", 0, 1),
        Caster("龍", 3, 2),
        1,
        [None, None],
        "戰士 is dead",
    ),
    (
        Caster("勇者", 4, 4),
        Caster("魔王", 3, 2),
        4,
        [None, None],
        "魔王 is dead",
    ),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(
    caster_1: Caster,
    caster_2: Caster,
    rounds: int,
    expected_result: ExpectedResult,
    expected_err: str | None,
) -> bool:
    print("---------------------------------")
    try:
        print("初始狀態：")
        caster_1.print_status()
        caster_2.print_status()
        for round_num in range(1, rounds + 1):
            print(f"\n第 {round_num} 回合：")
            print(f"* {caster_1.name} 的行動：")
            caster_1.cast_spell(caster_2)
            caster_2.print_status()
            print(f"* {caster_2.name} 的行動：")
            caster_2.cast_spell(caster_1)
            caster_1.print_status()

        print("\n最終狀態：")
        caster_1.print_status()
        caster_2.print_status()

        if expected_err:
            print(f"\n失敗：預期要拋出 {expected_err}，但沒有發生例外")
            return False

        _, caster_1_health, caster_1_mp = caster_1.get_status()
        _, caster_2_health, caster_2_mp = caster_2.get_status()
        assert expected_result[0] is not None
        assert expected_result[1] is not None
        caster_1_expected_health, caster_1_expected_mp = expected_result[0]
        caster_2_expected_health, caster_2_expected_mp = expected_result[1]
        print("\n結果檢查：")
        print(f"預期 {caster_1.name} 生命值：{caster_1_expected_health}")
        print(f"實際 {caster_1.name} 生命值：{caster_1_health}")
        print(f"預期 {caster_1.name} MP：{caster_1_expected_mp}")
        print(f"實際 {caster_1.name} MP：{caster_1_mp}")
        print(f"預期 {caster_2.name} 生命值：{caster_2_expected_health}")
        print(f"實際 {caster_2.name} 生命值：{caster_2_health}")
        print(f"預期 {caster_2.name} MP：{caster_2_expected_mp}")
        print(f"實際 {caster_2.name} MP：{caster_2_mp}")
        passed = (
            caster_1_health == caster_1_expected_health
            and caster_1_mp == caster_1_expected_mp
            and caster_2_health == caster_2_expected_health
            and caster_2_mp == caster_2_expected_mp
        )
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        error_msg = str(e)
        print(f"\n預期例外：{expected_err}")
        print(f"實際例外：{error_msg}")
        if expected_err and error_msg == expected_err:
            print("通過")
            return True
        print("失敗")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
