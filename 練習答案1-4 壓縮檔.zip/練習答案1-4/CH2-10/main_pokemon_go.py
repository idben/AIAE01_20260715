class Trainer:
    def __init__(self, name: str, poke_balls: int) -> None:
        self.name = name
        self.poke_balls = poke_balls

    def throw_ball(self, target: "WildPokemon") -> None:
        if self.poke_balls <= 0:
            raise Exception(f"{self.name} has no balls")
        self.poke_balls -= 1
        target.take_throw()

    def get_status(self) -> tuple[str, int]:
        return self.name, self.poke_balls

    def print_status(self) -> None:
        print(f"{self.name} 還有 {self.poke_balls} 顆球")


class WildPokemon:
    def __init__(self, name: str, catch_points: int) -> None:
        self.name = name
        self.catch_points = catch_points

    def take_throw(self) -> None:
        self.catch_points -= 1
        if self.catch_points <= 0:
            raise Exception(f"{self.name} is caught")

    def get_status(self) -> tuple[str, int]:
        return self.name, self.catch_points

    def print_status(self) -> None:
        print(f"{self.name} 還需要 {self.catch_points} 次命中")
