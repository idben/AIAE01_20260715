import subprocess
import sys
from pathlib import Path

from main import target_function

TestCase = tuple[object, object]

run_cases: list[TestCase] = [
    (1, 1),
]

submit_cases: list[TestCase] = run_cases + [
    (2, 2),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(value: object, expected: object) -> bool:
    print("---------------------------------")
    print(f"輸入：    {value}")
    print(f"預期：    {expected}")
    try:
        result = target_function(value)
        print(f"實際：    {result}")
        return result == expected
    except Exception as e:
        print(f"錯誤：    {e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        correct = test(*test_case)
        if correct:
            passed += 1
            print("通過")
        else:
            failed += 1
            print("失敗")
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
