def target_function(value):
    raise NotImplementedError("請把這裡改成學生作答內容")
