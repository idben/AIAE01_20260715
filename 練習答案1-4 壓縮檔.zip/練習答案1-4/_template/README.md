# 教材測試模板

這個資料夾提供「改寫教材版」的最小可用練習模板。

## 使用方式

1. 依照題目修改 `main.py`
2. 切換到該資料夾後執行：

```bash
python3 test.py
```

3. 如果最後看到 `============= PASS ==============`
   代表目前測試案例全部通過

## 學生操作說明

- 題目答案寫在 `main.py`
- 驗證程式寫在 `test.py`
- 一般情況下，只需要修改 `main.py`

## 常見錯誤

- `ImportError`
  代表測試要匯入的函式或類別名稱不存在

- `Expected` 和 `Actual` 不同
  代表程式可以執行，但結果不符合題目要求

- `command not found: python`
  請改用 `python3 test.py`
