class SpellCaster:
    def __init__(self, name: str, stamina: int, wisdom: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__wisdom = wisdom
        self.hp = stamina * 100
        self.mp = wisdom * 10
