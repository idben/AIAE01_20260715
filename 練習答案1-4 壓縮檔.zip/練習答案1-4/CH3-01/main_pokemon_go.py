class RaidPokemon:
    def __init__(self, name: str, stamina: int, charge_skill: int) -> None:
        self.name = name
        self.__stamina = stamina
        self.__charge_skill = charge_skill
        self.hp = stamina * 100
        self.energy = charge_skill * 10
