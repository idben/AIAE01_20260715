class PokemonSpawn:
    cp = 321
    remaining_seconds = 180


class PokeStop:
    distance_meters = 50
    is_lured = False
