class Monster:
    hp = 15
    gold_drop = 7


class Spell:
    mp_cost = 4
    power = 12
