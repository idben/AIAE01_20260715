import subprocess
import sys
from pathlib import Path

from main_pokemon_go import PokemonSpawn

ExpectedOutput = tuple[str, int, int]
TestCase = tuple[PokemonSpawn, ExpectedOutput]

run_cases: list[TestCase] = [
    (PokemonSpawn("Pikachu", 321, 180), ("Pikachu", 321, 180)),
    (PokemonSpawn("Eevee", 280, 95), ("Eevee", 280, 95)),
]

submit_cases: list[TestCase] = run_cases + [
    (PokemonSpawn("Snorlax", 2044, 240), ("Snorlax", 2044, 240)),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(spawn: PokemonSpawn, expected_output: ExpectedOutput) -> bool:
    print("---------------------------------")
    expected_name, expected_cp, expected_remaining_seconds = expected_output
    try:
        print("預期出現資料：")
        print("  - name:             ", expected_name)
        print("  - cp:               ", expected_cp)
        print("  - remaining_seconds:", expected_remaining_seconds)
        print("實際出現資料：")
        print("  - name:             ", spawn.name)
        print("  - cp:               ", spawn.cp)
        print("  - remaining_seconds:", spawn.remaining_seconds)
        passed = (
            spawn.name == expected_name
            and spawn.cp == expected_cp
            and spawn.remaining_seconds == expected_remaining_seconds
        )
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
