class PokemonSpawn:
    def __init__(self, name: str, cp: int, remaining_seconds: int) -> None:
        self.name = name
        self.cp = cp
        self.remaining_seconds = remaining_seconds
