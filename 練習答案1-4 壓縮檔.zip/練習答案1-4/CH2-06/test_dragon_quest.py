import subprocess
import sys
from pathlib import Path

from main_dragon_quest import PartyMember

ExpectedOutput = tuple[str, int, int]
TestCase = tuple[PartyMember, ExpectedOutput]

run_cases: list[TestCase] = [
    (PartyMember("勇者", 30, 10), ("勇者", 30, 10)),
    (PartyMember("魔法使", 18, 24), ("魔法使", 18, 24)),
]

submit_cases: list[TestCase] = run_cases + [
    (PartyMember("僧侶", 22, 18), ("僧侶", 22, 18)),
]


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        elif sys.platform.startswith("win"):
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    (
                        "Add-Type -AssemblyName presentationCore; "
                        "$player = New-Object System.Windows.Media.MediaPlayer; "
                        f"$player.Open([Uri]'{sound_path.as_uri()}'); "
                        "$player.Play(); "
                        "Start-Sleep -Seconds 3; "
                        "$player.Close()"
                    ),
                ],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def test(member: PartyMember, expected_output: ExpectedOutput) -> bool:
    print("---------------------------------")
    expected_name, expected_hp, expected_mp = expected_output
    try:
        print("預期隊友：")
        print("  - name:", expected_name)
        print("  - hp:  ", expected_hp)
        print("  - mp:  ", expected_mp)
        print("實際隊友：")
        print("  - name:", member.name)
        print("  - hp:  ", member.hp)
        print("  - mp:  ", member.mp)
        passed = (
            member.name == expected_name
            and member.hp == expected_hp
            and member.mp == expected_mp
        )
        if passed:
            print("通過")
        else:
            print("失敗")
        return passed
    except Exception as e:
        print(f"錯誤：{e}")
        return False


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        if test(*test_case):
            passed += 1
        else:
            failed += 1
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[TestCase] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
